import { Sequelize, DataTypes } from 'sequelize';

const sequelize = new Sequelize('my_db', 'root', 'R00t_password', {
  host: 'localhost',
  dialect: 'mysql',
});

const Branch = sequelize.define('Branch', {
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
});

export default Branch;
