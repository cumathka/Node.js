import companyRepository from '../data/CompanyRepository.js';

const getCompanyList = async () => {
  const companyList = await companyRepository.getCompanyList();
  return companyList;
};

const createCompany = (pCompany) => {
  return companyRepository.createCompany(pCompany);
};

const updateCompany = (pId, pCompany) => {
  return companyRepository.updateCompany(pId, pCompany);
};

const deleteCompany = (pId) => {
  companyRepository.deleteCompany(pId);
};

export default {
  getCompanyList,
  createCompany,
  updateCompany,
  deleteCompany,
};
