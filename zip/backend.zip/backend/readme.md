To access to the Api use the following URL
http://localhost:3000/api/employees