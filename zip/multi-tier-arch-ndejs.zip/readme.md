#prerequisites

please install nodemon globally
```
    npm install -g nodemon
```