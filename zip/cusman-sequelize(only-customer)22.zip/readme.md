# cusman

## Description

cusman is a customer managemetn system, which is supposed to make the life easier of a web agency. 
The project brings the most important entities together and give the users tool to manage them quickly.

## Installation

- First of all create the database "cusman" in the local or remote mysql database management system.
- Then create the schema by using the ddl file in the directory "/misc/ddl.sql"
- Then start the application by running 
    ```md
    npm start
    ```
- If you want to use nodemon then use the command 
    ```md
    npm run dev
    ```
- If ou want to debug the application, use the method "auto attach/always". You find more info iôn this page https://code.visualstudio.com/docs/nodejs/nodejs-debugging#_auto-attach

## Usage

In the directory "/misc" you find the postman collection to test the endpoints.


## Credits

tbd...

## License

tbd...

## Badges

tbd...

## Features

tbd...

## How to Contribute

tbd...

## Tests

tbd...