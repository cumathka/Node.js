CREATE TABLE movie_properties(
    movie_id INT AUTO_INCREMENT PRIMARY KEY,
    movie_name VARCHAR(30) NOT NULL, 
    movie_year INT NOT NULL , 
    movie_genre VARCHAR(20) NOT NULL,
    movie_income INT  
)