INSERT INTO 
movie_properties (movie_name, movie_year, movie_genre,movie_income)
values("Batman",1982,"Drama",999999)
