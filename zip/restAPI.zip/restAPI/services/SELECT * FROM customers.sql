SELECT * FROM customers
WHERE  contactFirstName LIKE "J_%"